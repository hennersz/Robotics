
void turn (char direction, double angle, double speed);
void straight(int targetSpeed, double distance);
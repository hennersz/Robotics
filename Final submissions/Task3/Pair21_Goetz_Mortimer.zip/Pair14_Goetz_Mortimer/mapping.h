void distanceTravelled(double* previousAngle, float* x, float* y, int* previousLeft, int* previousRight);
float ratio;
void calculateRatio();
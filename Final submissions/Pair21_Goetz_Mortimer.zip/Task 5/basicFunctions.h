
void turn (Mapping *mapping, char direction, double angle, double speed);
void straight(int targetSpeed, double distance);
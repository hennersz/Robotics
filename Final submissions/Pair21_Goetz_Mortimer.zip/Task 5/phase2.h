#include "turning.h"
#include "dijkstra.h"
void preparePointPhase2(Mapping *mapping, Point *targetPoint, int speed, int orientation);
#include "linkedList.h"
void dijkstra(bool walls[16][16], List *list, Point *points[16], int beginPoint, int endPoint);
#include "mapping.h"

void turn(Mapping *mapping, char direction, int angle, int speed);
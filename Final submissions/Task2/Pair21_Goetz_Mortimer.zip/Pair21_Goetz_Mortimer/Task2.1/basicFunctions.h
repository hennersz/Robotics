
void turn (char direction, float angle, float speed);
void straight(int targetSpeed, float distance);